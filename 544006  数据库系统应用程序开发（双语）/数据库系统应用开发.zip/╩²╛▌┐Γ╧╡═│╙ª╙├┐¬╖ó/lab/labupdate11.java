package lab;
import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import sqlj.runtime.*; 
import sqlj.runtime.ref.*;


public class labupdate11 {
private static Connection con = null;
public static void main( String args[]) throws Exception
{
	try{
		Class.forName ("COM.ibm.db2.jdbc.app.DB2Driver");
		System.out.println("���ڽ�������");
		con = DriverManager.getConnection("jdbc:db2:sample");
		System.out.println("�������");
		con.setAutoCommit(false);
	} catch (Exception e) {
		System.out.println ("DB2���������ӳ���");
		System.out.println (e);
		System.exit(1);
	}

	String empnum = "000130";
	int startper, startper1, startdpt;
	startper = startper1 = startdpt = 0;
	PreparedStatement stmt1, stmt2, stmt3;
	stmt1 = stmt2 = stmt3 = null;
	String sql1, sql2, sql3;
	sql1 = sql2 = sql3 = null;
	String empno, resumefmt;
	empno = resumefmt = null;
	Clob resumelob = null;
	ResultSet rs1, rs2, rs3;
	rs1 = rs2 = rs3 = null;
	sql1 = "SELECT POSSTR(RESUME,'Personal') "
			+ "FROM EMP_RESUME "
			+ "WHERE EMPNO = ? AND RESUME_FORMAT = 'ascii' ";
	stmt1 = con.prepareStatement (sql1);
	stmt1.setString ( 1, empnum);
	rs1 = stmt1.executeQuery();
	while (rs1.next())
		startper = rs1.getInt(1);
	
	sql2 = "SELECT POSSTR(RESUME,'Department') "
			+ "FROM EMP_RESUME "
			+ "WHERE EMPNO = ? AND RESUME_FORMAT = 'ascii' ";
	stmt2 = con.prepareStatement (sql2);
	stmt2.setString ( 1, empnum);
	rs2 = stmt2.executeQuery();
	while (rs2.next())
		startdpt = rs2.getInt(1);
	
	startper1 = startper - 1;
	sql3 = "SELECT EMPNO, RESUME_FORMAT, "
			+ "SUBSTR(RESUME,1,?)|| SUBSTR(RESUME,?) AS RESUME "
			+ "FROM EMP_RESUME "
			+ "WHERE EMPNO = ? AND RESUME_FORMAT = 'ascii' ";
	stmt3 = con.prepareStatement (sql3);
	stmt3.setInt (1, startper1);
	stmt3.setInt (2, startdpt);
	stmt3.setString ( 3, empnum);
	rs3 = stmt3.executeQuery();
	while (rs3.next()) {
	empno = rs3.getString(1);
	resumefmt = rs3.getString(2);
	resumelob = rs3.getClob(3);
	long len = resumelob.length();
	int len1 = (int)len;
	String resumeout = resumelob.getSubString(1, len1);
	System.out.println(resumeout);//���
	} // end while
	System.out.println("end of main");
	
}//End of main
}
