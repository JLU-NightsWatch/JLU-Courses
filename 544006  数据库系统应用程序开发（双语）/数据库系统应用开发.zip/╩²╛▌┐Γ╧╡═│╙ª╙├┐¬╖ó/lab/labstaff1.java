package lab;

import java.sql.*;
import java.io.*;
import java.util.*;
import java.math.*;

public class labstaff1 
{
static{
	try { 
		Class.forName ("COM.ibm.db2.jdbc.app.DB2Driver");
	} catch (Exception e) {
		System.exit(1);
	}
}

public static void main( String args[]) throws Exception
{
int mydeptno = 0;
String deptno = "";
String outline = " ";
String name = " ";
String job = " ";
String salary = "";

String  intext = "\n ID       NAME      SALARY\n";
String  indash = "--------  --------  --------------\n";
String blanks = "                                                        ";


SQLWarning SQLWarn = null;

Connection sample = DriverManager.getConnection("jdbc:db2:sample");
 
System.out.println("\n Set AutoCommit off");
sample.setAutoCommit( false);
System.out.println("\n Autocommit off");
try {  
	System.out.println("\n Enter the Department number\n");
	BufferedReader in = new BufferedReader( new InputStreamReader (System.in));
	String s;
	s = in.readLine();
	deptno = s.substring(0,2);
	mydeptno = Integer.parseInt(deptno);
} catch (Exception e) {
	e.printStackTrace();
	System.exit(0);
}
try { 
	PreparedStatement stmt = sample.prepareStatement("select id, name,salary from staff where Dept = ?");
	stmt.setInt(1, mydeptno);
	ResultSet rs = stmt.executeQuery();                   

	if ( (SQLWarn = stmt.getWarnings()) != null ) {
		System.out.println ("\n Value of SQLWarn on single row insert to DEP is: \n");
		System.out.println (SQLWarn);
	} // end if
	
	boolean more = rs.next();
	System.out.println ( intext );
	System.out.println ( indash );                                  

	while ( more ) {
		name = rs.getString(1);
		job = rs.getString(2);
		salary = rs.getString(3);
		outline = (name + blanks.substring(0, 10 - name.length())) +
				(job + blanks.substring(0, 10 - job.length()))   +
				(salary + blanks.substring(0, 12 - salary.length()));
		System.out.println("\n" + outline);

		more = rs.next();
	}
} catch (Exception e) {
	System.exit(1); }
}
}