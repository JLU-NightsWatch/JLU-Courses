package lab;

import java.sql.*;
import java.io.*;
import java.util.*;
import java.math.*;
import javax.swing.JOptionPane;

public class labupdate4
{
static
{
	try
	{   
		Class.forName ("COM.ibm.db2.jdbc.app.DB2Driver");
	}catch (Exception e)
	{
		System.out.println ("\n  Error loading DB2 Driver...\n");
		System.out.println (e);
		System.exit(1);
	}
}

public static void main( String args[]) throws Exception
{
	String name = "";
	java.lang.String deptno  = "";
	short id = 0;
	double salary = 0;
	String job = "";
	short NumEmp = 0;
	String sqlstmt = "UPDATE STAFF SET SALARY = SALARY * 1.05 WHERE DEPT = ?";
	String s = " ";
	int mydeptno = 0;
	int SQLCode = 0;
	String SQLState = "     ";
	BufferedReader in = new BufferedReader( new InputStreamReader (System.in));
	
	/*
	connect to the database
	*/
	System.out.println("���ڽ�������");
	Connection sample=DriverManager.getConnection("jdbc:db2:sample"/*,"db2admin","db2admin"*/);
	System.out.println("�������");
	sample.setAutoCommit(false);
	System.out.println("�������һ�����²���");  
	System.out.println("\n");    
/*                              
	System.out.println("Please enter a department number: \n ");                         
*/	
	s = JOptionPane.showInputDialog(null,"������Ҫ��н�Ĳ��ű��");
	System.out.println("asd");
/*
	s = in.readLine();
*/
	try{
		deptno = s.substring(0,2);
		mydeptno = Integer.parseInt(deptno);
	}catch(Exception e){
		System.out.println("�����쳣�������˳�");
		System.exit(0);
	}
	System.out.println("ִ��SQL���");
	try 
	{
		PreparedStatement pstmt = sample.prepareStatement( sqlstmt );
		pstmt.setInt(1, mydeptno);
		int updateCount = pstmt.executeUpdate();
		JOptionPane.showMessageDialog(null,"��ɸ��µĴ���: "+updateCount,"�޸ĳɹ�",JOptionPane.INFORMATION_MESSAGE);
/*
		System.out.println("\nNumber of rows updated: " + updateCount);
*/
	}catch ( SQLException x )
	{
		SQLCode = x.getErrorCode();
		SQLState = x.getSQLState();
		String Message = x.getMessage();
		JOptionPane.showMessageDialog(null,"\nSQLCODE:  "+SQLCode+"\nSQLSTATE: "+SQLState+"\nSQLERRM:  "+Message,"�����쳣",JOptionPane.ERROR_MESSAGE);
		System.out.println("SQL���ִ���쳣�������˳�");
		System.exit(0);
/*
		System.out.println("\nSQLCODE:  " + SQLCode );
		System.out.println("\nSQLSTATE: " + SQLState);
		System.out.println("\nSQLERRM:  " + Message);
*/
	}
	System.out.println("���гɹ����������");
	System.exit(0);
}//End of main
}//End of class