package lab;
import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;

public class labupdate10
{
private Connection sample = null;
private JFrame jf = new JFrame("����10��picture");

private void createConnection()//����DB2���ݿ����ӣ�ͬʱ��ʾҳ��
{
	try{
		Class.forName ("COM.ibm.db2.jdbc.app.DB2Driver");
		System.out.println("���ڽ�������");
		sample = DriverManager.getConnection("jdbc:db2:sample");
		System.out.println("�������");
		sample.setAutoCommit(false);
	} catch (Exception e) {
		System.out.println ("DB2���������ӳ���");
		System.out.println (e);
		System.exit(1);
	}
	jf.setBounds(100,100,300,200);
	jf.getContentPane().setLayout(new FlowLayout(FlowLayout.CENTER,5,5));
	JButton jb1 = new JButton("��ѯ");
	JButton jb2 = new JButton("����");
	jf.getContentPane().add(jb1);
	jf.getContentPane().add(jb2);
	jf.setVisible(true);
	jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	jb1.addActionListener(new ActionListener() {//��ѯ��ť
		public void actionPerformed(ActionEvent e) {
			function1();
		}
	});
	jb2.addActionListener(new ActionListener() {//���밴ť
		public void actionPerformed(ActionEvent e) {
			function2();
		}
	});
}

private void function1()//��ѯҳ��
{
	JFrame jf = new JFrame("��ѯ");
	jf.setBounds(100,100,300,150);
	jf.getContentPane().setLayout(new FlowLayout(FlowLayout.CENTER,5,5));
	JLabel jl = new JLabel("����Ҫ��ѯ�ı�ţ�");
	final JTextField jt = new JTextField(10);
	JButton jb = new JButton("ȷ��");
	jf.getContentPane().add(jl);
	jf.getContentPane().add(jt);
	jf.getContentPane().add(jb);
	jf.getContentPane().add(new JLabel("��ע�⣺��ѯ���ͼƬ���������c:/output.jpg"));
	jf.setVisible(true);
	jb.addActionListener(new ActionListener() {//��ѯ��ť
		public void actionPerformed(ActionEvent e) {
			String number = jt.getText();
			try{
				String sql = "select picture from emp_photo where empno=?";
				PreparedStatement st = sample.prepareStatement(sql);
				st.setString(1, number);
				ResultSet rs = st.executeQuery();
				rs.next();
				Blob blob = rs.getBlob(1);
				InputStream inputStream = blob.getBinaryStream();
				File fileOutput = new File("c:/output.jpg");
				FileOutputStream fo = new FileOutputStream(fileOutput);
				int c;
				while((c = inputStream.read()) != -1)
					fo.write(c);
				fo.close();
				JOptionPane.showMessageDialog(null,"ͼƬ�Ѿ������c:/output.jpg");
			} catch(Exception ee) {
				System.out.println("��ѯ����");
				ee.printStackTrace();
			}
		}
	});
}

private void function2()//����ҳ��
{
	JFrame jf = new JFrame("����");
	jf.setBounds(100,100,400,200);
	jf.getContentPane().setLayout(new GridLayout(3,1));
	JPanel jp1 = new JPanel();
	JLabel jl1 = new JLabel("������Ա�����");
	final JTextField jt1 = new JTextField(10);
	jp1.add(jl1);jp1.add(jt1);
	JPanel jp2 = new JPanel();
	JLabel jl2 = new JLabel("��Ҫ���ӵ�ͼƬ����c:/my.jpg");
	final JTextField jt2 = new JTextField(20);
	jp2.add(jl2);jp2.add(jt2);
	JPanel jp3 = new JPanel();
	JButton jb = new JButton("ȷ��");
	jp3.add(jb);
	jf.getContentPane().add(jp1);
	jf.getContentPane().add(jp2);
	jf.getContentPane().add(jp3);
	jf.setVisible(true);
	jb.addActionListener(new ActionListener() {//���밴ť
		public void actionPerformed(ActionEvent e) {
			String number = jt1.getText();
			String path = jt2.getText();
			try{
				String sql = "insert into emp_photo values(?,'jpg',?)";
				PreparedStatement st = sample.prepareStatement(sql);
				File file = new File(path);
				BufferedInputStream imageInput = new BufferedInputStream(new FileInputStream(file));
				st.setString(1, number);
				st.setBinaryStream(2, imageInput,(int) file.length());
				st.executeUpdate();
				sample.commit();
				JOptionPane.showMessageDialog(null,"���ӳɹ�");
			} catch(SQLException ee) {
				System.out.println("���Ӵ���");
				System.out.println(ee.getMessage());
				System.out.println("1");
				System.out.println(ee.getSQLState());
				System.out.println("2");
				System.out.println(ee.getErrorCode());
				System.out.println("3");
				ee.printStackTrace();
			} catch (Exception eee){
				System.out.println("!!���Ӵ���");
			}
		}
	});
	
}

public static void main( String args[]) throws Exception
{
	labupdate10 l10 = new labupdate10();
	l10.createConnection();
	System.out.println("end of main");

}//End of main
}