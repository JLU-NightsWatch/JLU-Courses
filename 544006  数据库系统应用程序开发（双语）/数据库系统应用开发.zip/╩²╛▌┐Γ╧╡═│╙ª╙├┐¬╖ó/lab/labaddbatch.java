package lab;

import java.sql.*;
import java.io.*;
import java.util.*;
import java.math.*;

public class labaddbatch
{
static{
	try{
		Class.forName ("COM.ibm.db2.jdbc.app.DB2Driver");
	} catch (Exception e) {
		System.out.println ("\n  Error loading DB2 Driver...\n");
		System.out.println (e);
		System.exit(1);
	}
}

public static void main( String args[]) throws Exception
{
int outID = 0;
String outname = " ";
String outjob = " ";
float outsalary = 0; 
int updaterowcount = 0;

try {
	System.out.println("Connect statement follows:");

	Connection sample =
			DriverManager.getConnection("jdbc:db2:sample");
	System.out.println("Connect completed");

//	sample.setAutoCommit(false);                                                  

	System.out.println("\nAutocommit set off");

	Statement stmt = sample.createStatement();                                     

	System.out.println("\n Batch Statements begin ");
	
	stmt.addBatch("INSERT INTO DEPARTMENT " +
			"VALUES ('BT6','BATCH6 NEWYORK','000020','A00','NEW YORK CITY6')");
	stmt.addBatch("INSERT INTO DEPARTMENT " +
			"VALUES ('BT7','BATCH7 NEWYORK','000030','A00','NEW YORK CITY7')");
	stmt.addBatch("INSERT INTO DEPARTMENT " +
			"VALUES ('BT8','BATCH8 NEWYORK','000060','D01','NEW YORK CITY8')");
	stmt.addBatch("INSERT INTO DEPARTMENT " +
			"VALUES ('BT9','BATCH9 NEWYORK','000070','D01','NEW YORK CITY9')");
	stmt.addBatch("INSERT INTO DEPARTMENT " +
			"VALUES ('BTA','BATCH10 NEWYORK','000100','E01','NEW YORK CITY10')");

	System.out.println("\n Batch statements completed executeBatch follows");

	int [] updateCounts = stmt.executeBatch();
	for (int i = 0; i < updateCounts.length; i++) {
		System.out.println("\nUpdate row count " + updateCounts[i] );
	}

	//sample.commit();
} catch (SQLException e) {
	System.out.println("\n SQLState: " + e.getSQLState() + " SQLCode: " + e.getErrorCode());
	System.out.println("\n Message " + e);
	System.out.println("\n Get Error Message: " + e.getMessage());
}
}
}