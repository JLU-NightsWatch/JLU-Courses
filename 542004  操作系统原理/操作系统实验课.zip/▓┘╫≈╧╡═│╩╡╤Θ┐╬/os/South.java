package os;
/*
 * South是MainFrame中下侧部分的JPanel组件
 * 用于返回一个具有版权声明的JPanel
 */
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class South extends JPanel {
	private Font ft = new Font("微软雅黑", Font.BOLD, 12);
	private JLabel jl1 = new JLabel("© 2018 吉林大学 软件学院 操作系统实验课 何宇鹏&李奕  All rights reserved", JLabel.CENTER);
	private JLabel jl2 = new JLabel("联系我们：834613101@qq.com    Tel：13604568355    QQ：834613101", JLabel.CENTER);
	public South() {
		this.setLayout(new GridLayout(2, 1, 0, 0));
		this.setBackground(Color.GRAY);
		jl1.setFont(ft);
		jl2.setFont(ft);
		this.add(jl1);
		this.add(jl2);
		this.setVisible(true);
	}
}
